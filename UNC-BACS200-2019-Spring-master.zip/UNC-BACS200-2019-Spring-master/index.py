for x in range(40):
    print('<li><a href="index.php?lesson=%02d">Lesson %d</a></li>' % (x,x))

